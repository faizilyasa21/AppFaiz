package com.apprandom.app.ui.favorite

import androidx.lifecycle.ViewModel

class FavoriteViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}